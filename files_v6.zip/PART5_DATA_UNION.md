# Part 5: Combine Counties and Offices into One Table (MapItems)

## Why
The visual reads ONE table. Each row must be either a county (a shape) OR an office (a
point), never both. When you feed it county shapes and office points from two separate
tables at once, Power BI cross-joins them: it makes a row for every shape-and-point
combination. That shreds your member counts into tiny numbers and puts a shape on every
row, so no pins ever appear. The cure is to stack the two into one table yourself, so the
grains stay clean.

You will build a table called **MapItems** with these columns, in this order:
`id, name, region, wkt, lat, lon, colorValue, sizeValue`
- county rows fill id, name, region, wkt, colorValue (lat/lon/sizeValue blank)
- office rows fill id, name, lat, lon, sizeValue (region/wkt/colorValue blank)

## Two things to fill in (your real column names)
Before you start, find these in your MembershipTable and use them wherever you see the
placeholder:
- **<CountyLink>** = the column in MembershipTable that ties a member to their county
  (the one already linking to FL_Counties_WKT). It is whatever made the WKT-only map color
  correctly. It is probably a FIPS code or a county name.
- **<OfficeName>** = the provider or PCP name column (what you want shown on a pin's tooltip).

This guide assumes MembershipTable has ONE ROW PER MEMBER, so counting rows = counting
members. If your "Members" figure is built some other way, swap "Count Rows" below for your
own logic.

---

## APPROACH A: Static totals (do this first, it always works)

This gets both layers rendering fast. The numbers are totals frozen at refresh time, so
slicers will not recolor the map. If you need slicer-responsive numbers, do Approach B after.

### Step 1
Home > **Transform data** to open Power Query.

### Step 2: county member counts
1. In the left Queries list, right-click **MembershipTable** > **Reference**. Rename the new
   query **CountyMembers**.
2. Select the **<CountyLink>** column. Home > **Group By**.
3. Group by **<CountyLink>**. New column name **colorValue**, Operation **Count Rows**. OK.
   You now have two columns: <CountyLink> and colorValue.

### Step 3: shape the Counties query
1. Right-click **FL_Counties_WKT** > **Reference**. Rename it **Counties**.
2. Home > **Merge Queries**. Pick **CountyMembers**, match **id** to **<CountyLink>** (if
   your link is a county name, match name to name instead). Join kind **Left Outer**. OK.
3. Expand the new column (the little arrow on its header), tick only **colorValue**, untick
   "use original column name as prefix". OK.
4. Add Column > **Custom Column** three times to create blanks:
   - column **lat**, formula `= null`
   - column **lon**, formula `= null`
   - column **sizeValue**, formula `= null`
5. Home > **Choose Columns** and keep exactly: id, name, region, wkt, lat, lon, colorValue,
   sizeValue. (Reorder by dragging headers if needed.)

### Step 4: build the Offices query
1. Right-click **MembershipTable** > **Reference**. Rename it **Offices**.
2. Home > **Group By** > **Advanced**.
3. Add three group-by rows: **PRAD_LAT**, **PRAD_LONG**, **<OfficeName>**.
4. New column name **sizeValue**, Operation **Count Rows**. OK.
   You now have one row per office with its lat, lon, name, and member count.
5. Rename and add columns so they match Counties exactly:
   - rename **<OfficeName>** to **name**
   - rename **PRAD_LAT** to **lat**, **PRAD_LONG** to **lon**
   - Add Custom Column **id**, formula `= [name]` (or use a provider ID column if you have one)
   - Add Custom Column **region**, formula `= null`
   - Add Custom Column **wkt**, formula `= null`
   - Add Custom Column **colorValue**, formula `= null`
6. Choose Columns and keep exactly the same eight, same order: id, name, region, wkt, lat,
   lon, colorValue, sizeValue.

### Step 5: stack them
1. Home > **Append Queries** > **Append Queries as New**.
2. Pick **Counties** and **Offices**. OK. Rename the result **MapItems**.

### Step 6
Home > **Close & Apply**.

### Step 7: map the fields
Drop a fresh Region & Pin Map visual and set:
- **ID / Category** = MapItems[id]
- **Shape (WKT)** = MapItems[wkt]
- **Latitude** = MapItems[lat]  (open its dropdown, choose **Don't summarize**)
- **Longitude** = MapItems[lon]  (also **Don't summarize**)
- **Color value** = MapItems[colorValue]  (it will read "Sum of colorValue", that is fine)
- **Size value** = MapItems[sizeValue]
- **Tooltips** = MapItems[name], MapItems[region]

Counties now color by member total and offices appear as pins sized by member total. Both
layers, one visual.

---

## APPROACH B: Slicer-responsive (optional upgrade)

Do this only after Approach A renders. It swaps the frozen columns for live measures so
slicers (region, department, date) recolor and resize the map.

### Step 1: build MapItems without the count columns
Repeat Approach A, but SKIP the colorValue and sizeValue columns everywhere. MapItems ends
up as just: id, name, region, wkt, lat, lon. County id stays your <CountyLink> value, office
id stays the office name.

Uniqueness note: every id must be unique across counties and offices. If an office name
could ever equal a county code, prefix them. In Counties set id = "C-" & [id], in Offices set
id = "P-" & [id], and in MembershipTable add matching keys (see Step 2).

### Step 2: relationships (Model view)
1. Click the **Model** icon on the far left.
2. Drag **MembershipTable[<CountyLink>]** onto **MapItems[id]**. This first link is active.
3. Drag **MembershipTable[<OfficeName>]** onto **MapItems[id]**. Power BI marks this second
   link inactive (a dotted line). That is correct.
   (If you prefixed ids in Step 1, first add two columns in MembershipTable:
   CountyKey = "C-" & [<CountyLink>], OfficeKey = "P-" & [<OfficeName>], and link those.)

### Step 3: two measures
Right-click MapItems > New measure, for each:
```
ColorByCounty = COUNTROWS('MembershipTable')
```
```
SizeByOffice =
CALCULATE(
    COUNTROWS('MembershipTable'),
    USERELATIONSHIP('MembershipTable'[<OfficeName>], MapItems[id])
)
```

### Step 4: point the wells at the measures
- **Color value** = ColorByCounty
- **Size value** = SizeByOffice

Now a region or department slicer refilters both the county shading and the pin sizes live.

---

## Note on versions
This rendering problem is a data-model issue, not a visual bug, so updating the visual will
not change it. That said, you are still on v1.2.0; grab v1.3.1 when convenient for the
Logarithmic color mode and the raised class cap. Fix the union first, since that is what is
blocking the combined map.
